package com.rahol.dualcam

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.MeteringRectangle
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Size
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "DualCam"
        private const val REQ = 1001
        private val PERMS = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
    }

    private lateinit var mainPreview: TextureView
    private lateinit var pipPreview: TextureView
    private lateinit var pip: FrameLayout
    private lateinit var status: TextView
    private lateinit var btnModePhoto: TextView
    private lateinit var btnModeVideo: TextView
    private lateinit var btnCapture: FrameLayout
    private lateinit var shutterOuter: View
    private lateinit var shutterInner: View
    private lateinit var btnDual: TextView
    private lateinit var btnFlash: TextView
    private lateinit var btnGrid: TextView
    private lateinit var btnSwitch: TextView
    private lateinit var btnSettings: TextView
    private lateinit var gridOverlay: View
    private lateinit var zoomBar: SeekBar
    private lateinit var thumbPreview: ImageView
    private lateinit var photoViewer: FrameLayout
    private lateinit var photoFull: ImageView
    private lateinit var btnDeletePhoto: TextView
    private lateinit var btnClosePhoto: TextView

    private var mgr: CameraManager? = null
    private var mainDev: CameraDevice? = null
    private var pipDev: CameraDevice? = null
    private var mainSess: CameraCaptureSession? = null
    private var pipSess: CameraCaptureSession? = null
    private var backId: String? = null
    private var frontId: String? = null
    private var bgThread: HandlerThread? = null
    private var bgHandler: Handler? = null
    private val lock = Semaphore(1)

    private var imageReader: ImageReader? = null
    private var recorder: MediaRecorder? = null
    private var lastVideoFile: File? = null
    private var lastPhotoFile: File? = null

    private var dX = 0f
    private var dY = 0f

    private var isPhotoMode = true
    private var isRecording = false
    private var dualOn = false
    private var gridOn = false
    private var mainIsBack = true
    private var flashMode = 0
    private var zoomLevel = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mainPreview = findViewById(R.id.mainPreview)
        pipPreview = findViewById(R.id.pipPreview)
        pip = findViewById(R.id.pipContainer)
        status = findViewById(R.id.statusText)
        btnModePhoto = findViewById(R.id.btnModePhoto)
        btnModeVideo = findViewById(R.id.btnModeVideo)
        btnCapture = findViewById(R.id.btnCapture)
        shutterOuter = findViewById(R.id.shutterOuter)
        shutterInner = findViewById(R.id.shutterInner)
        btnDual = findViewById(R.id.btnDual)
        btnFlash = findViewById(R.id.btnFlash)
        btnGrid = findViewById(R.id.btnGrid)
        btnSwitch = findViewById(R.id.btnSwitch)
        btnSettings = findViewById(R.id.btnSettings)
        gridOverlay = findViewById(R.id.gridOverlay)
        zoomBar = findViewById(R.id.zoomBar)
        thumbPreview = findViewById(R.id.thumbPreview)
        photoViewer = findViewById(R.id.photoViewer)
        photoFull = findViewById(R.id.photoFull)
        btnDeletePhoto = findViewById(R.id.btnDeletePhoto)
        btnClosePhoto = findViewById(R.id.btnClosePhoto)

        mgr = getSystemService(CAMERA_SERVICE) as CameraManager

        shutterOuter.setBackgroundResource(R.drawable.shutter_outer)
        shutterInner.setBackgroundResource(R.drawable.shutter_inner_photo)

        btnModePhoto.setOnClickListener { setMode(true) }
        btnModeVideo.setOnClickListener { setMode(false) }
        btnCapture.setOnClickListener { onCaptureClick() }
        btnDual.setOnClickListener { toggleDual() }
        btnFlash.setOnClickListener { cycleFlash() }
        btnGrid.setOnClickListener { toggleGrid() }
        btnSwitch.setOnClickListener { switchCameras() }
        btnSettings.setOnClickListener { showSettings() }
        btnClosePhoto.setOnClickListener { photoViewer.visibility = View.GONE }
        btnDeletePhoto.setOnClickListener {
            lastPhotoFile?.let { f -> if (f.exists()) f.delete() }
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
            photoViewer.visibility = View.GONE
            thumbPreview.setImageDrawable(null)
        }
        thumbPreview.setOnClickListener {
            if (thumbPreview.drawable != null) photoViewer.visibility = View.VISIBLE
        }

        zoomBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                zoomLevel = progress / 100f
                applyZoom()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        pip.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = v.x - e.rawX; dY = v.y - e.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    v.animate().x(e.rawX + dX).y(e.rawY + dY).setDuration(0).start()
                    true
                }
                else -> false
            }
        }

        // Tap-to-focus on main preview
        mainPreview.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                triggerFocus(e.x, e.y, v.width, v.height)
                v.performClick()
            }
            true
        }

        if (PERMS.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            startBg(); setupMain()
        } else {
            ActivityCompat.requestPermissions(this, PERMS, REQ)
        }
    }

    private fun setMode(photo: Boolean) {
        if (isRecording) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        isPhotoMode = photo
        if (photo) {
            btnModePhoto.setTextColor(0xFFFFFFFF.toInt())
            btnModePhoto.setBackgroundColor(0x33FFFFFF)
            btnModeVideo.setTextColor(0xAAFFFFFF.toInt())
            btnModeVideo.setBackgroundColor(0)
            shutterInner.setBackgroundResource(R.drawable.shutter_inner_photo)
        } else {
            btnModeVideo.setTextColor(0xFFFFFFFF.toInt())
            btnModeVideo.setBackgroundColor(0x33FFFFFF)
            btnModePhoto.setTextColor(0xAAFFFFFF.toInt())
            btnModePhoto.setBackgroundColor(0)
            shutterInner.setBackgroundResource(R.drawable.shutter_inner_video)
        }
        updateStatus()
    }

    // ---------- Dual camera ----------

    private fun isDualSupported(): Boolean {
        val back = backId ?: return false
        val front = frontId ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return try {
                mgr!!.concurrentCameraIds.any { it.containsAll(listOf(back, front)) }
            } catch (e: Exception) {
                false
            }
        }
        // Below API 30 there's no official way to query concurrent support.
        // Most single-ISP devices will fail with ERROR_MAX_CAMERAS_IN_USE, so
        // we don't attempt a blind open on old APIs to avoid confusing errors.
        return false
    }

    private fun toggleDual() {
        if (isRecording) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        if (!dualOn) {
            if (!isDualSupported()) {
                Toast.makeText(this, "Is device par dual camera supported nahi hai", Toast.LENGTH_LONG).show()
                status.text = "Dual not supported on this device"
                return
            }
        }
        dualOn = !dualOn
        if (dualOn) {
            btnDual.text = "Dual ON"
            btnDual.setBackgroundColor(0x66E53935)
            pip.alpha = 0f
            pip.visibility = View.VISIBLE
            pip.animate().alpha(1f).setDuration(300).start()
            openPip()
            status.text = "Opening second camera…"
        } else {
            btnDual.text = "Dual OFF"
            btnDual.setBackgroundColor(0x33FFFFFF)
            pip.animate().alpha(0f).setDuration(200).withEndAction {
                pip.visibility = View.GONE
                closePipOnly()
            }.start()
            updateStatus()
        }
    }

    private fun switchCameras() {
        if (isRecording) {
            Toast.makeText(this, "Stop recording first", Toast.LENGTH_SHORT).show()
            return
        }
        mainIsBack = !mainIsBack
        closeAll()
        Handler(mainLooper).postDelayed({
            openMain()
            if (dualOn) openPip()
        }, 200)
    }

    private fun cycleFlash() {
        flashMode = (flashMode + 1) % 3
        btnFlash.text = when (flashMode) {
            1 -> "Flash On"
            2 -> "Flash Auto"
            else -> "Flash Off"
        }
        restartMainPreview()
    }

    private fun toggleGrid() {
        gridOn = !gridOn
        gridOverlay.visibility = if (gridOn) View.VISIBLE else View.GONE
        btnGrid.setTextColor(if (gridOn) 0xFFFFFFFF.toInt() else 0xAAFFFFFF.toInt())
    }

    private fun showSettings() {
        val items = arrayOf("Shutter sound: ON", "About Dual Cam")
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(items) { _, which ->
                if (which == 0) Toast.makeText(this, "Sound toggle (coming)", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this, "Dual Cam v1 - Camera2 PIP", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun onCaptureClick() {
        if (isPhotoMode) {
            capturePhoto()
        } else {
            if (!isRecording) startRecording() else stopRecording()
        }
    }

    private fun updateStatus() {
        val mode = if (isPhotoMode) "PHOTO" else "VIDEO"
        val dual = if (dualOn) " · Dual" else ""
        val cam = if (mainIsBack) "Back" else "Front"
        status.text = "$mode$dual · $cam"
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == REQ && r.all { it == PackageManager.PERMISSION_GRANTED }) {
            startBg(); setupMain()
        } else status.text = "Permission required"
    }

    private fun startBg() {
        bgThread = HandlerThread("cam").also { it.start() }
        bgHandler = Handler(bgThread!!.looper)
    }

    private fun setupMain() {
        mainPreview.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) {
                findIds(); openMain()
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
        pipPreview.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) {
                if (dualOn && mainDev != null) openPip()
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
        if (mainPreview.isAvailable) { findIds(); openMain() }
    }

    private fun findIds() {
        try {
            for (id in mgr!!.cameraIdList) {
                val f = mgr!!.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)
                if (f == CameraCharacteristics.LENS_FACING_BACK && backId == null) backId = id
                if (f == CameraCharacteristics.LENS_FACING_FRONT && frontId == null) frontId = id
            }
        } catch (e: Exception) {
            status.text = "Camera list error"
        }
    }

    private fun mainCamId(): String? = if (mainIsBack) backId else frontId
    private fun pipCamId(): String? = if (mainIsBack) frontId else backId

    private fun errorMsg(code: Int): String = when (code) {
        1 -> "Camera in use"
        2 -> "Max cameras in use (device doesn't support dual)"
        3 -> "Camera disabled"
        4 -> "Camera device error"
        5 -> "Camera service error"
        else -> "Error $code"
    }

    private fun openMain() {
        val id = mainCamId() ?: return
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        try {
            if (!lock.tryAcquire(3, TimeUnit.SECONDS)) return
            mgr!!.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) {
                    lock.release(); mainDev = c
                    setupImageReader()
                    startPreview(c, mainPreview, false)
                    updateStatus()
                }
                override fun onDisconnected(c: CameraDevice) { lock.release(); c.close(); mainDev = null }
                override fun onError(c: CameraDevice, e: Int) {
                    lock.release(); c.close(); mainDev = null
                    status.text = "Main: ${errorMsg(e)}"
                }
            }, bgHandler)
        } catch (e: Exception) {
            lock.release(); status.text = "Main fail"
        }
    }

    private fun openPip() {
        val id = pipCamId() ?: run {
            status.text = "No second camera"
            dualOn = false
            btnDual.text = "Dual OFF"
            pip.visibility = View.GONE
            return
        }
        if (pipDev != null) return
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        try {
            if (!lock.tryAcquire(3, TimeUnit.SECONDS)) {
                status.text = "PIP timeout"
                return
            }
            mgr!!.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) {
                    lock.release()
                    pipDev = c
                    startPreview(c, pipPreview, true)
                    status.text = "Dual ON · ready"
                }
                override fun onDisconnected(c: CameraDevice) {
                    lock.release(); c.close(); pipDev = null
                }
                override fun onError(c: CameraDevice, e: Int) {
                    lock.release(); c.close(); pipDev = null
                    dualOn = false
                    runOnUiThread {
                        btnDual.text = "Dual OFF"
                        btnDual.setBackgroundColor(0x33FFFFFF)
                        pip.visibility = View.GONE
                        status.text = "Dual failed: ${errorMsg(e)}"
                    }
                    Log.e(TAG, "PIP error $e")
                }
            }, bgHandler)
        } catch (e: Exception) {
            lock.release()
            status.text = "PIP fail"
        }
    }

    private fun closePipOnly() {
        try {
            pipSess?.close()
            pipDev?.close()
        } catch (_: Exception) {}
        pipSess = null
        pipDev = null
    }

    private fun chooseSize(isPip: Boolean): Size {
        val id = if (isPip) pipCamId() else mainCamId()
        return try {
            val map = mgr!!.getCameraCharacteristics(id!!)
                .get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map!!.getOutputSizes(SurfaceTexture::class.java)
            sizes.firstOrNull { it.width <= 1280 && it.height <= 720 }
                ?: sizes.minByOrNull { it.width * it.height } ?: Size(640, 480)
        } catch (_: Exception) {
            Size(640, 480)
        }
    }

    private fun flashValue(): Int = when (flashMode) {
        1 -> CaptureRequest.FLASH_MODE_TORCH
        2 -> CaptureRequest.FLASH_MODE_SINGLE
        else -> CaptureRequest.FLASH_MODE_OFF
    }

    private fun startPreview(device: CameraDevice, view: TextureView, isPip: Boolean) {
        val tex = view.surfaceTexture ?: return
        val size = chooseSize(isPip)
        tex.setDefaultBufferSize(size.width, size.height)
        val surface = Surface(tex)
        try {
            val targets = mutableListOf(surface)
            if (!isPip) imageReader?.let { targets.add(it.surface) }
            val req = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(surface)
                set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                if (!isPip && mainIsBack) {
                    try {
                        set(CaptureRequest.FLASH_MODE, flashValue())
                    } catch (_: Exception) {}
                }
            }
            device.createCaptureSession(targets, object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (isPip) pipSess = s else mainSess = s
                    try {
                        s.setRepeatingRequest(req.build(), null, bgHandler)
                        if (!isPip) applyZoom()
                    } catch (e: Exception) {
                        Log.e(TAG, "repeat", e)
                    }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    status.text = if (isPip) "PIP config fail" else "Main config fail"
                }
            }, bgHandler)
        } catch (e: Exception) {
            Log.e(TAG, "preview", e)
        }
    }

    private fun applyZoom() {
        val sess = mainSess ?: return
        val dev = mainDev ?: return
        if (isRecording) return // don't touch the recording session
        try {
            val id = mainCamId() ?: return
            val chars = mgr!!.getCameraCharacteristics(id)
            val maxZoom = chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
            val active = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
            val centerX = active.width() / 2
            val centerY = active.height() / 2
            val cropW = (active.width() / (1f + zoomLevel * (maxZoom - 1f))).toInt()
            val cropH = (active.height() / (1f + zoomLevel * (maxZoom - 1f))).toInt()
            val left = centerX - cropW / 2
            val top = centerY - cropH / 2
            val crop = Rect(left, top, left + cropW, top + cropH)
            val tex = mainPreview.surfaceTexture ?: return
            val surface = Surface(tex)
            val req = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(surface)
                imageReader?.let { addTarget(it.surface) }
                set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                set(CaptureRequest.SCALER_CROP_REGION, crop)
                if (mainIsBack) {
                    try { set(CaptureRequest.FLASH_MODE, flashValue()) } catch (_: Exception) {}
                }
            }
            sess.setRepeatingRequest(req.build(), null, bgHandler)
        } catch (e: Exception) {
            Log.e(TAG, "zoom", e)
        }
    }

    private fun restartMainPreview() {
        val dev = mainDev ?: return
        if (isRecording) return
        try { mainSess?.close() } catch (_: Exception) {}
        startPreview(dev, mainPreview, false)
    }

    // ---------- Tap to focus ----------

    private fun triggerFocus(x: Float, y: Float, viewWidth: Int, viewHeight: Int) {
        if (isRecording) return
        val dev = mainDev ?: return
        val sess = mainSess ?: return
        val id = mainCamId() ?: return
        try {
            val chars = mgr!!.getCameraCharacteristics(id)
            val active = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
            val maxAfRegions = chars.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0
            val maxAeRegions = chars.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0
            if (maxAfRegions <= 0 && maxAeRegions <= 0) return // device doesn't support tap focus

            val areaSize = (active.width() * 0.1f).toInt().coerceAtLeast(50)
            val cx = (x / viewWidth * active.width()).toInt()
            val cy = (y / viewHeight * active.height()).toInt()
            val left = (cx - areaSize / 2).coerceIn(0, active.width() - areaSize)
            val top = (cy - areaSize / 2).coerceIn(0, active.height() - areaSize)
            val rect = Rect(left, top, left + areaSize, top + areaSize)
            val region = arrayOf(MeteringRectangle(rect, MeteringRectangle.METERING_WEIGHT_MAX - 1))

            val tex = mainPreview.surfaceTexture ?: return
            val surface = Surface(tex)
            val req = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(surface)
                imageReader?.let { addTarget(it.surface) }
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
                if (maxAfRegions > 0) set(CaptureRequest.CONTROL_AF_REGIONS, region)
                if (maxAeRegions > 0) set(CaptureRequest.CONTROL_AE_REGIONS, region)
                set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
            }
            sess.capture(req.build(), null, bgHandler)
            // resume continuous AF + zoom after the manual focus settles
            Handler(mainLooper).postDelayed({ applyZoom() }, 1200)
        } catch (e: Exception) {
            Log.e(TAG, "focus", e)
        }
    }

    // ---------- Photo capture ----------

    private fun setupImageReader() {
        val id = mainCamId() ?: return
        try {
            val map = mgr!!.getCameraCharacteristics(id).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(ImageFormat.JPEG)
            val size = sizes?.firstOrNull { it.width <= 1920 && it.height <= 1080 }
                ?: sizes?.maxByOrNull { it.width.toLong() * it.height } ?: Size(1280, 720)
            imageReader?.close()
            imageReader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 2).apply {
                setOnImageAvailableListener({ reader ->
                    val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    image.close()
                    savePhoto(bytes)
                }, bgHandler)
            }
        } catch (e: Exception) {
            Log.e(TAG, "imageReader setup", e)
        }
    }

    private fun getJpegOrientation(): Int {
        val id = mainCamId() ?: return 0
        return try {
            val chars = mgr!!.getCameraCharacteristics(id)
            val sensorOrientation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
            // Activity is locked to portrait, so device rotation is always 0.
            if (mainIsBack) sensorOrientation else (360 - sensorOrientation) % 360
        } catch (_: Exception) { 0 }
    }

    private fun capturePhoto() {
        val dev = mainDev ?: return
        val sess = mainSess ?: return
        val reader = imageReader ?: return
        try {
            val req = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(reader.surface)
                set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation())
                if (mainIsBack) {
                    try { set(CaptureRequest.FLASH_MODE, flashValue()) } catch (_: Exception) {}
                }
            }
            sess.capture(req.build(), null, bgHandler)
        } catch (e: Exception) {
            Log.e(TAG, "capture", e)
            runOnUiThread { Toast.makeText(this, "Capture failed", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun savePhoto(bytes: ByteArray) {
        try {
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_DCIM), "DualCam")
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "IMG_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { it.write(bytes) }
            lastPhotoFile = file
            scanFile(file)
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            runOnUiThread {
                thumbPreview.setImageBitmap(bmp)
                photoFull.setImageBitmap(bmp)
                Toast.makeText(this, "Saved: ${file.name}", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "save photo", e)
        }
    }

    // ---------- Video recording ----------

    private fun setupRecorder(): Boolean {
        val id = mainCamId() ?: return false
        return try {
            val chars = mgr!!.getCameraCharacteristics(id)
            val size = chooseSize(false)
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_DCIM), "DualCam")
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "VID_${System.currentTimeMillis()}.mp4")
            lastVideoFile = file

            recorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setOutputFile(file.absolutePath)
                setVideoEncodingBitRate(8_000_000)
                setVideoFrameRate(30)
                setVideoSize(size.width, size.height)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                val sensorOrientation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
                setOrientationHint(sensorOrientation)
                prepare()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "recorder setup", e)
            recorder?.release()
            recorder = null
            false
        }
    }

    private fun startRecording() {
        val dev = mainDev ?: return
        if (!setupRecorder()) {
            Toast.makeText(this, "Recording setup failed", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            mainSess?.close()
            val tex = mainPreview.surfaceTexture ?: return
            val size = chooseSize(false)
            tex.setDefaultBufferSize(size.width, size.height)
            val previewSurface = Surface(tex)
            val recorderSurface = recorder!!.surface
            val req = dev.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                addTarget(previewSurface)
                addTarget(recorderSurface)
                set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
            }
            dev.createCaptureSession(listOf(previewSurface, recorderSurface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    mainSess = s
                    try {
                        s.setRepeatingRequest(req.build(), null, bgHandler)
                        recorder?.start()
                        isRecording = true
                        runOnUiThread {
                            shutterInner.setBackgroundResource(R.drawable.shutter_inner_recording)
                            status.text = "Recording…"
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "rec start", e)
                        runOnUiThread { Toast.makeText(this@MainActivity, "Recording start failed", Toast.LENGTH_SHORT).show() }
                    }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "Recording setup failed", Toast.LENGTH_SHORT).show() }
                }
            }, bgHandler)
        } catch (e: Exception) {
            Log.e(TAG, "startRecording", e)
        }
    }

    private fun stopRecording() {
        try { mainSess?.stopRepeating() } catch (_: Exception) {}
        try { recorder?.stop() } catch (e: Exception) { Log.e(TAG, "recorder stop", e) }
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        isRecording = false
        lastVideoFile?.let { scanFile(it) }
        runOnUiThread {
            shutterInner.setBackgroundResource(R.drawable.shutter_inner_video)
            updateStatus()
            Toast.makeText(this, "Saved: ${lastVideoFile?.name}", Toast.LENGTH_SHORT).show()
        }
        restartMainPreview()
    }

    private fun scanFile(file: File) {
        try {
            MediaScannerConnection.scanFile(this, arrayOf(file.absolutePath), null, null)
        } catch (_: Exception) {}
    }

    // ---------- Lifecycle ----------

    private fun closeAll() {
        try {
            lock.acquire()
            if (isRecording) {
                try { recorder?.stop() } catch (_: Exception) {}
                try { recorder?.release() } catch (_: Exception) {}
                recorder = null
                isRecording = false
            }
            mainSess?.close(); pipSess?.close()
            mainDev?.close(); pipDev?.close()
            imageReader?.close()
            mainSess = null; pipSess = null
            mainDev = null; pipDev = null
            imageReader = null
        } catch (_: Exception) {
        } finally {
            lock.release()
        }
    }

    override fun onResume() {
        super.onResume()
        if (PERMS.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            startBg()
            if (mainPreview.isAvailable) {
                findIds(); openMain()
                if (dualOn) openPip()
            } else setupMain()
        }
    }

    override fun onPause() {
        closeAll()
        bgThread?.quitSafely()
        bgThread = null
        bgHandler = null
        super.onPause()
    }
}
